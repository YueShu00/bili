﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Interfaces
{
    /// <summary>
    /// 用户操作API
    /// </summary>
    public interface IUserOperationApi
    {
    }
}
