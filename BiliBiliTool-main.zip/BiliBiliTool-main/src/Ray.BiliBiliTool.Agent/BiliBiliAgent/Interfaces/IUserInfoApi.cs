﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Interfaces
{
    /// <summary>
    /// 用户信息接口API
    /// </summary>
    public interface IUserInfoApi
    {
    }
}
