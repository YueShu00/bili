﻿namespace Ray.BiliBiliTool.Agent.BiliBiliAgent.Dtos
{
    public class MangaVipRewardResponse
    {
        public int Amount { get; set; }
    }
}
